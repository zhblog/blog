import amessage_pb2 as apb
am = apb.AMessage()
am.a = 1
am.b = 2
buf = am.SerializeToString()
print len(buf)
# OUT: 4
ma = apb.AMessage()
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: unbound method ParseFromString() must be called with AMessage instance as first argument (got str instance instead)
import time
print time.ctime()
for i in range(1000000):
    apb.AMessage.ParseFromString(ma, buf)
print time.ctime()

import dpkt
class test(dpkt.Packet):
    __hdr__ = (
        ('a', 'i', 0),
        ('b', 'i', 0)
    )

t = test(a = 1, b = 2)
t.a
buf = t.pack()

t1 = test(a = 2, b = 1)
print len(buf)
print time.ctime()
for i in range(1000000):
    dpkt.Packet.unpack(t1,buf)
print t1.a
print t1.b
print time.ctime()
