import amessage_pb2 as a

aa = a.AMessage()
a.a = 1
aa.a = 1
aa.b = 2
buf = ""


aa.SerializeToString(buf)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: SerializeToString() takes exactly 1 argument (2 given)
buf = aa.SerializeToString()


bb = a.AMessage()

a.AMessage.ParseFromString(bb, buf)
bb.a
# OUT: 1L
