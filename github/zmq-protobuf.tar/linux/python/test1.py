print 0xff
# OUT: 255
import dpkt
class test(dpkt.Packet):
    __hdr__ = (
        ('a', 'H', 0),
        ('b', 'H', 0)
    )

t = test(a = 1, b = 2)
t.a
# OUT: 1
buf = t.pack()

dpkt.Packet.unpack(t,buf)
