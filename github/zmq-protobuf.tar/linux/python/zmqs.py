#
#   Hello World server in Python
#   Binds REP socket to tcp://*:5555
#   Expects "Hello" from client, replies with "World"
#
import zmq
import time
import amessage_pb2 as APB 

context = zmq.Context()
socket = context.socket(zmq.REP)
socket.bind("tcp://*:5555")

am = APB.AMessage()
while True:
    #  Wait for next request from client
    buf = socket.recv()
    print "Received request: ", len(buf)
    print repr(buf)
    APB.AMessage.ParseFromString(am, buf)
    print am.a
    print am.b
    #  Do some 'work'
    time.sleep (1)        #   Do some 'work'

    #  Send reply back to client
    socket.send("World")

socket.close()
