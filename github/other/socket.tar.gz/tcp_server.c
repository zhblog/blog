//tcp 服务端,server:
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/stat.h>
#include<arpa/inet.h>
#include <sys/types.h>
#include <netinet/in.h>
#define MAXBUF 256
int main()
{
    int clen;
    int ssock,csock;
    struct sockaddr_in client_addr,server_addr;
    char buf[MAXBUF];
    if((ssock=socket(PF_INET,SOCK_STREAM,IPPROTO_TCP))<0){
        perror("socket error:");
        exit(1);
    }
    clen = sizeof(client_addr);
    memset(&server_addr,0,sizeof(server_addr));
    server_addr.sin_family     =AF_INET;
    server_addr.sin_addr.s_addr=htonl(INADDR_ANY);
    //server_addr.sin_addr.s_addr=htonl(inet_addr("192.168.1.254"));
    server_addr.sin_port=htons(6002);
    if(bind(ssock,(struct sockaddr *)&server_addr,sizeof(server_addr))<0){
        perror("bind error");
        exit(1);
    }
    if(listen(ssock,8)<0){
        perror("listen error:");
        exit(1);
    }
    while(1){
        csock=accept(ssock,(struct sockaddr *)&client_addr,&clen);
        if(write(csock,buf, MAXBUF)<=0)
            perror("write error:");
        close(csock);
    }
    return 0;
}
