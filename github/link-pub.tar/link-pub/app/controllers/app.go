package controllers

import "github.com/robfig/revel"

type Link struct {
	Name    string
	Title   string
	Address string
	Type    string
}

var links []Link

type Application struct {
	*revel.Controller
}

/*
htmlStr := "<table><tr><td>link name</td><td>from</td><td>type</td></tr>"
	for lnk := range links {
		htmlStr = htmlStr + "<tr><td>" + links[lnk].Title + "</td>"
		htmlStr = htmlStr + "<td>" + links[lnk].Name + "</td>"
		htmlStr = htmlStr + "<td>" + links[lnk].Type + "</td></tr>"
	}
	htmlStr = htmlStr + "</table>"
*/

func (c Application) Index() revel.Result {

	return c.Render(links)
}

func (c Application) AddLink(link_title string, link_address string, link_username string, link_type string) revel.Result {
	var link Link
	link.Name = link_username
	link.Type = link_type
	link.Address = link_address
	link.Title = link_title
	links = append(links, link)

	return c.Render(links)
}
